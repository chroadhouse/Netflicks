# Netflicks

The project aims to create a website that uses a movie database and provides services to allow a user to be able to log in and search movies by various different contriants. 

## Technologies 
This will be done using HTML, CSS, JavaScript, PHP and MYSQl. These are the languages that will be used to create this site. 
HTML - Setting the webiste out and creating the components that will be used 
CSS - Styling the HTML to create a professional evniroment 
JavaScript - Front end validation on any search terms 
PHP - All actions in back end such as sanatizing data, encrypt/decrypt data, sorting data and running queries
MySQl - Used to access the database and retreve data to be used on the site.

## Setup
To be able to run the website you must install Mamp or Xamp to run a virtual server. You must also import the data set into the virtual server. 
